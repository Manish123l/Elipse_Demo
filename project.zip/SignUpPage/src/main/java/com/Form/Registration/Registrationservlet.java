package com.Form.Registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/register")
public class Registrationservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	String uname=request.getParameter("name");

	String uemail=request.getParameter("email");
	String uaadhar=request.getParameter("aadhar no");
	String uage=request.getParameter("age");
	String upass=request.getParameter("pass");
	String ucontact=request.getParameter("contact");
	PrintWriter out= response.getWriter();
	RequestDispatcher dis=null; 
	Connection connection =null;
	
	 try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/userbiometric?useSSL=false&allowPublicKeyRetrieval=true";

         
         String userName = "root";
         String password = "Manish123@";
 
        connection = DriverManager.getConnection(url,userName, password);
 
        
 
         PreparedStatement pst = connection.prepareStatement("insert into user(uname,uemail,uaadhar,uage,upass,ucontact) values(?,?,?,?,?,?)");

         pst.setString(1, uname);
         pst.setString(2, uemail);
         pst.setString(3, uaadhar);
         pst.setString(4, uage);
         pst.setString(5, upass);
         pst.setString(6, ucontact);
         
         int count=pst.executeUpdate();
         dis=request.getRequestDispatcher("registration.jsp");
         if(count>0)
         {
        	 request.setAttribute("status", "success");
         }
         else
         {
        	 request.setAttribute("status","Failed");
         }
         dis.forward(request,response);
        
     } catch (Exception e) {
         e.printStackTrace();
     }
	 finally {
		 try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	
	}

}
